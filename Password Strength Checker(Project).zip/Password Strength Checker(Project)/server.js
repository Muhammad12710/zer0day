const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const PORT = 3000;

// JSON data parsing
app.use(bodyParser.json());

// Connecting static files from the public folder
app.use(express.static('public'));

// Route for password verification
app.post('/check-password', (req, res) => {
    const password = req.body.password;
    const strength = checkPasswordStrength(password);

    res.json({ level: strength });
});

// Redirect to the main page
app.get('/ca', (req, res) => {
    res.redirect('/');
});

// Route to return the HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Password strength check function
function checkPasswordStrength(password) {
    let strength = 0;

    if (password.length >= 4 && password.length <= 6) {
        strength += 1;
    }
    if (password.length > 6 && password.length <= 8) {
        strength += 1;
    }
    if (password.length > 8) {
        strength += 1;
    }
    if (password.match(/([a-z].*[A-Z])|([A-Z].*[a-z])/)) {
        strength += 1;
    }
    if (password.match(/([A-Z])/)) {
        strength += 1;
    }
    if (password.match(/([0-9])/)) {
        strength += 1;
    }
    if (password.match(/.[!,@,#,$,%,^,&,*,?,_,~,-,(,)]/)) {
        strength += 1;
    }

    return strength;
}

// Starting the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});


